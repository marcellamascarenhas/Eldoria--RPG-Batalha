import pygame
import random
from collections import deque
import copy

# ==========================================0
# CONSTANTES DO JOGO
# ==========================================
VIDA_HEROI = 100
VIDA_FORTALEZA = 150
VIDA_DRAGAO = 500
CURA_POCAO = 10
CURA_CURANDEIRO = 10
BONUS_GUERREIRO = 0.21
BONUS_PERGAMINHO = 0.10
CHANCE_CRITICO_ARQUEIRO = 30
REDUCAO_ESCUDEIRO = 0.50

pygame.init()

# Músicas
pygame.mixer.init()

try:
    musica_fundo = pygame.mixer.music.load("musica_fundo.mp3")
    som_batalha_auto = pygame.mixer.Sound("batalha.mp3")
    som_encontro_pocao = pygame.mixer.Sound("pocao.mp3")
    som_encontro_pergaminho = pygame.mixer.Sound("pergaminho.mp3")
    som_morte_jogador = pygame.mixer.Sound("morte_jogador.mp3")
    som_vitoria = pygame.mixer.Sound("vitoria.mp3")
    som_derrota = pygame.mixer.Sound("derrota.mp3")
    pygame.mixer.music.play(-1)
except pygame.error:
    print("Aviso: Arquivos de áudio não encontrados. O jogo rodará sem som.")
    som_batalha_auto = som_encontro_pocao = som_encontro_pergaminho = None
    som_morte_jogador = som_vitoria = som_derrota = None

# ==========================================
# 1. CONFIGURAÇÕES DA JANELA E TABULEIRO
# ==========================================
LARGURA_ORIGINAL = 991
ALTURA_ORIGINAL = 730
# Permite o redimensionamento da janela
janela = pygame.display.set_mode((LARGURA_ORIGINAL, ALTURA_ORIGINAL), pygame.RESIZABLE)
# Cria a tela virtual para desenhar os gráficos em tamanho fixo
tela_virtual = pygame.Surface((LARGURA_ORIGINAL, ALTURA_ORIGINAL))
pygame.display.set_caption("Eldoria")

# Paleta de cores da interface
C_BG = (180, 156, 131)
C_GRID = (119, 148, 102)
C_CELL_BASE = (120, 189, 93)
C_HIGHLIGHT = (150, 255, 150, 130)
C_TEXTO = (0, 0, 0)
C_BORDA_TEXTO = (146, 114, 77)
C_SIDEBAR_BG = (160, 136, 111)

# O mapa tem 12x12 células (Tiles)
LARGURA_CELULA = 792 // 12
ALTURA_CELULA = 530 // 12

# Carregamento de Fontes
try:
    fonte = pygame.font.Font('NewRocker-Regular.ttf', 24)
    fonte_pequena = pygame.font.Font('NewRocker-Regular.ttf', 18)
    fonte_titulo = pygame.font.Font('NewRocker-Regular.ttf', 36) # Fonte maior para o título
except FileNotFoundError:
    print("Aviso: Arquivo 'NewRocker-Regular.ttf' não encontrado. Usando fonte padrão.")
    fonte = pygame.font.Font(None, 24)
    fonte_pequena = pygame.font.Font(None, 18)
    fonte_titulo = pygame.font.Font(None, 36)

# ==========================================
# 2. FUNÇÕES DE AUXÍLIO PARA O MAPA E IMAGENS
# ==========================================
pontos_criticos = [(0, 0), (2, 5), (5, 10), (8, 3), (6, 6), (11, 11)]
posicoes_ocupadas = set(pontos_criticos)


def tocar_som(som):
    if som:
        try:
            som.play()
        except Exception:
            pass


def carregar_imagem(nome_arquivo, tamanho):
    try:
        return pygame.transform.scale(pygame.image.load(nome_arquivo), tamanho)
    except pygame.error:
        print(f"❌ ERRO: Não encontrei a imagem '{nome_arquivo}'! Verifique o nome/pasta.")
        surf_erro = pygame.Surface(tamanho)
        surf_erro.fill((255, 0, 255))
        return surf_erro


def area_segura_para_obstaculo(col, lin):
    for cx, cy in pontos_criticos:
        if abs(col - cx) <= 1 and abs(lin - cy) <= 1:
            return False
    return True


def muito_proximo(col, lin, grupo_existente, dist_min=1):
    for item in grupo_existente:
        cx, cy = item if isinstance(item, tuple) else (item["coluna"], item["linha"])
        if abs(col - cx) <= dist_min and abs(lin - cy) <= dist_min:
            return True
    return False


def celulas_adjacentes(col, lin):
    adjacentes = []
    for dc in [-1, 0, 1]:
        for dl in [-1, 0, 1]:
            if dc == 0 and dl == 0:
                continue
            nc, nl = col + dc, lin + dl
            if 0 <= nc <= 11 and 0 <= nl <= 11:
                adjacentes.append((nc, nl))
    return adjacentes


def desenhar_destaque_transparente(tela, x, y, largura, altura, cor_rgba):
    surface_celula = pygame.Surface((largura, altura), pygame.SRCALPHA)
    surface_celula.fill(cor_rgba)
    tela.blit(surface_celula, (x, y))


def desenhar_texto_com_contorno(superficie, texto, fonte_usada, cor_texto, cor_borda, x, y):
    offsets = [(-1, -1), (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1)]
    for ox, oy in offsets:
        borda_surf = fonte_usada.render(texto, True, cor_borda)
        superficie.blit(borda_surf, (x + ox, y + oy))
    texto_surf = fonte_usada.render(texto, True, cor_texto)
    superficie.blit(texto_surf, (x, y))


# ==========================================
# PATHFINDING BFS — Dragão desvia de obstáculos
# ==========================================
def bfs_proximo_passo(origem, destino, bloqueados):
    if origem == destino:
        return None

    fila = deque([origem])
    pai = {origem: None}

    while fila:
        atual = fila.popleft()
        if atual == destino:
            caminho = []
            while atual is not None:
                caminho.append(atual)
                atual = pai[atual]
            caminho.reverse()
            return caminho[1] if len(caminho) > 1 else None

        c, l = atual
        for nc, nl in [(c + 1, l), (c - 1, l), (c, l + 1), (c, l - 1)]:
            vizinho = (nc, nl)
            if (0 <= nc <= 11 and 0 <= nl <= 11
                    and vizinho not in pai
                    and vizinho not in bloqueados):
                pai[vizinho] = atual
                fila.append(vizinho)

    return None


# ==========================================
# 3. GERAÇÃO DO MUNDO
# ==========================================
mapa_estruturas = {
    (6, 6): "dragao",
    (2, 5): "fortaleza1",
    (5, 10): "fortaleza2",
    (8, 3): "fortaleza3",
    (11, 11): "santuario"
}

vida_estruturas = {
    "fortaleza1": VIDA_FORTALEZA,
    "fortaleza2": VIDA_FORTALEZA,
    "fortaleza3": VIDA_FORTALEZA,
    "dragao": VIDA_DRAGAO
}

ordem_fortalezas = ["fortaleza1", "fortaleza2", "fortaleza3"]
fortaleza_atual_index = 0
turnos_jogados = 0

lista_obstaculos_gerar = ["arvore_folhas"] * 3 + ["arvore_seca"] * 3 + ["estatua"] * 3 + ["pedra"] * 3 + ["muro"] * 3
lista_itens_gerar = ["pocao"] * 15 + ["pergaminho"] * 5

mapa_obstaculos = {}
mapa_itens = {}
lista_inimigos = []

visuais_objetos = {
    "arvore_folhas": carregar_imagem('Estruturas_ArvoresComFolhasV2.png', (60, 60)),
    "arvore_seca": carregar_imagem('Estruturas_ArvoresSemFolhasV2.png', (60, 60)),
    "estatua": carregar_imagem('Estruturas_Estatua.png', (70, 56)),
    "pedra": carregar_imagem('Estruturas_Pedra.png', (50, 50)),
    "muro": carregar_imagem('Estruturas_Muro.png', (65, 85)),
    "pocao": carregar_imagem('Item_Pocao.png', (45, 55)),
    "pergaminho": carregar_imagem('Item_PergaminhoV2.png', (45, 55)),
    "dragao": carregar_imagem('Dragao_Adormecido.png', (100, 120)),
    "dragao_acordado": carregar_imagem('Dragao_Acordado.png', (100, 120)),
    "fortaleza1": carregar_imagem('Fortaleza_1.png', (75, 55)),
    "fortaleza2": carregar_imagem('Fortaleza_2.png', (75, 55)),
    "fortaleza3": carregar_imagem('Fortaleza_3.png', (75, 55)),
    "santuario": carregar_imagem('Santuario_Dragao.png', (75, 60)),
    "base": carregar_imagem('base.png', (65, 65))
}


def inicializar_elementos_mapa():
    global mapa_obstaculos, mapa_itens, posicoes_ocupadas, lista_inimigos
    mapa_obstaculos.clear()
    mapa_itens.clear()
    posicoes_ocupadas = set(mapa_estruturas.keys())

    for obs in lista_obstaculos_gerar:
        while True:
            c, l = random.randint(0, 11), random.randint(0, 11)
            if (c, l) not in posicoes_ocupadas and area_segura_para_obstaculo(c, l):
                mapa_obstaculos[(c, l)] = obs
                posicoes_ocupadas.add((c, l))
                break

    for item in lista_itens_gerar:
        tentativas = 0
        while True:
            c, l = random.randint(0, 11), random.randint(0, 11)
            if (c, l) not in posicoes_ocupadas:
                if tentativas < 50 and muito_proximo(c, l, mapa_itens.keys(), dist_min=1):
                    tentativas += 1
                    continue
                mapa_itens[(c, l)] = item
                posicoes_ocupadas.add((c, l))
                break

    lista_inimigos.clear()
    for _ in range(30):
        tentativas = 0
        while True:
            c, l = random.randint(0, 11), random.randint(0, 11)
            if (c, l) not in posicoes_ocupadas:
                if tentativas < 50 and muito_proximo(c, l, lista_inimigos, dist_min=1):
                    tentativas += 1
                    continue
                lista_inimigos.append({"coluna": c, "linha": l})
                posicoes_ocupadas.add((c, l))
                break


# ==========================================
# 4. CONFIGURAÇÕES DOS PERSONAGENS
# ==========================================
imagens = {
    "guerreiro": carregar_imagem('Sprite_Guerreiro.png', (55, 60)),
    "arqueiro": carregar_imagem('Sprite_Arqueiro.png', (55, 60)),
    "curandeiro": carregar_imagem('Sprite_Curandeiro.png', (55, 60)),
    "mago": carregar_imagem('Sprite_Mago.png', (55, 60)),
    "escudeiro": carregar_imagem('Sprite_Escudeiro.png', (55, 60))
}

retratos = {
    "guerreiro": carregar_imagem('Selecionado_Guerreiro.png', (230, 230)),
    "arqueiro": carregar_imagem('Selecionado_Arqueiro.png', (280, 280)),
    "curandeiro": carregar_imagem('Selecionado_Curandeiro.png', (210, 255)),
    "mago": carregar_imagem('Selecionado_Mago.png', (260, 290)),
    "escudeiro": carregar_imagem('Selecionado_Escudeiro.png', (240, 240))
}

posicoes_customizadas = {
    "guerreiro": {"retrato": (-5, 525), "texto": (70, 695)},
    "arqueiro": {"retrato": (-25, 520), "texto": (75, 690)},
    "curandeiro": {"retrato": (0, 515), "texto": (65, 700)},
    "mago": {"retrato": (-18, 510), "texto": (70, 695)},
    "escudeiro": {"retrato": (-8, 510), "texto": (72, 692)}
}


def criar_herois():
    return {
        "guerreiro": {"coluna": 0, "linha": 0, "vida": VIDA_HEROI, "vida_max": VIDA_HEROI, "classe": "guerreiro",
                      "bonus_ataque": 1 + BONUS_GUERREIRO, "pergaminhos": 0, "curas_recebidas": 0,
                      "protecoes_recebidas": 0},
        "arqueiro": {"coluna": 0, "linha": 0, "vida": VIDA_HEROI, "vida_max": VIDA_HEROI, "classe": "arqueiro",
                     "bonus_ataque": 1.0, "pergaminhos": 0, "curas_recebidas": 0, "protecoes_recebidas": 0},
        "curandeiro": {"coluna": 0, "linha": 0, "vida": VIDA_HEROI, "vida_max": VIDA_HEROI, "classe": "curandeiro",
                       "bonus_ataque": 1.0, "pergaminhos": 0, "curas_recebidas": 0, "protecoes_recebidas": 0},
        "mago": {"coluna": 0, "linha": 0, "vida": VIDA_HEROI, "vida_max": VIDA_HEROI, "classe": "mago",
                 "bonus_ataque": 1.0,
                 "pergaminhos": 0, "curas_recebidas": 0, "protecoes_recebidas": 0},
        "escudeiro": {"coluna": 0, "linha": 0, "vida": VIDA_HEROI, "vida_max": VIDA_HEROI, "classe": "escudeiro",
                      "bonus_ataque": 1.0, "pergaminhos": 0, "protegendo": None, "curas_recebidas": 0,
                      "protecoes_recebidas": 0}
    }


herois = criar_herois()
personagem_selecionado = "guerreiro"
estado_jogo = "EXPLORACAO"
mensagem_log = []


def adicionar_log(msg):
    global mensagem_log
    tempo_atual = pygame.time.get_ticks()
    mensagem_log.append({"texto": msg, "tempo": tempo_atual})
    if len(mensagem_log) > 3:
        mensagem_log.pop(0)


# ==========================================
# 5. GERAÇÃO DOS INIMIGOS E SNAPSHOT INICIAL
# ==========================================
imagem_inimigo = carregar_imagem('Sprite_Inimigo.png', (40, 55))
inicializar_elementos_mapa()

mapa_obstaculos_inicial = copy.deepcopy(mapa_obstaculos)
mapa_itens_inicial = copy.deepcopy(mapa_itens)
lista_inimigos_inicial = copy.deepcopy(lista_inimigos)


# ==========================================
# 6. FUNÇÕES DE COMBATE
# ==========================================
def verificar_estado_jogo():
    global estado_jogo
    if sum(1 for h in herois.values() if h["vida"] > 0) == 0:
        pygame.mixer.music.stop()
        tocar_som(som_derrota)
        estado_jogo = "DERROTA"
        adicionar_log("DERROTA! Todos os heróis foram derrotados.")


def aplicar_dano_com_protecao(nome_heroi, dano_total):
    if herois["escudeiro"]["vida"] > 0 and herois["escudeiro"]["protegendo"] == nome_heroi:
        metade_dano = int(dano_total * REDUCAO_ESCUDEIRO)

        herois[nome_heroi]["vida"] = max(0, herois[nome_heroi]["vida"] - metade_dano)
        herois["escudeiro"]["vida"] = max(0, herois["escudeiro"]["vida"] - metade_dano)

        adicionar_log(
            f"Escudeiro dividiu o dano! {nome_heroi.capitalize()}: -{metade_dano} HP | Escudeiro: -{metade_dano} HP")

        if herois["escudeiro"]["vida"] <= 0:
            tocar_som(som_morte_jogador)
            adicionar_log("Escudeiro foi derrotado protegendo seu aliado!")
            herois["escudeiro"]["protegendo"] = None
    else:
        herois[nome_heroi]["vida"] = max(0, herois[nome_heroi]["vida"] - dano_total)
        adicionar_log(f"{nome_heroi.capitalize()} recebe {dano_total} de dano!")

    if herois[nome_heroi]["vida"] == 0:
        tocar_som(som_morte_jogador)
        adicionar_log(f"{nome_heroi.capitalize()} foi derrotado!")


def realizar_encontro_inimigo(nome_heroi, inimigo):
    lista_inimigos.remove(inimigo)
    tocar_som(som_batalha_auto)

    dano_inicial = 5
    adicionar_log(f"{nome_heroi.capitalize()} derrotou inimigo!")
    aplicar_dano_com_protecao(nome_heroi, dano_inicial)


def obter_herois_aptos_para_atacar(estrutura_pos):
    herois_aptos = []
    ex, ey = estrutura_pos

    for nome, dados in herois.items():
        if dados["vida"] > 0:
            distancia = abs(dados["coluna"] - ex) + abs(dados["linha"] - ey)
            distancia_maxima = 3 if dados["classe"] == "mago" else 1
            if distancia <= distancia_maxima:
                herois_aptos.append(nome)

    return herois_aptos


def calcular_dano_fortaleza(nome_heroi):
    dados = herois[nome_heroi]
    dano = 15
    if dados["classe"] == "guerreiro":
        dano = int(dano * (1 + BONUS_GUERREIRO))
    dano = int(dano * (1 + dados["pergaminhos"] * BONUS_PERGAMINHO))
    if dados["classe"] == "arqueiro":
        if random.randint(1, 100) <= CHANCE_CRITICO_ARQUEIRO:
            dano *= 2
            adicionar_log(f"CRÍTICO! {nome_heroi.capitalize()} causa dano dobrado!")
    return dano


def calcular_dano_dragao(nome_heroi):
    dados = herois[nome_heroi]
    dano = 20
    if dados["classe"] == "guerreiro":
        dano = int(dano * (1 + BONUS_GUERREIRO))
    dano = int(dano * (1 + dados["pergaminhos"] * BONUS_PERGAMINHO))
    if dados["classe"] == "arqueiro":
        if random.randint(1, 100) <= CHANCE_CRITICO_ARQUEIRO:
            dano *= 2
            adicionar_log(f"CRÍTICO! {nome_heroi.capitalize()} causa dano dobrado!")
    return dano


def realizar_ataque_fortaleza():
    global fortaleza_atual_index, estado_jogo
    if fortaleza_atual_index >= len(ordem_fortalezas): return

    nome_fortaleza = ordem_fortalezas[fortaleza_atual_index]
    pos_fortaleza = next((pos for pos, tipo in mapa_estruturas.items() if tipo == nome_fortaleza), None)

    if not pos_fortaleza: return

    herois_aptos = obter_herois_aptos_para_atacar(pos_fortaleza)
    if len(herois_aptos) < 2:
        adicionar_log(f"Precisa de 2+ heróis no alcance da {nome_fortaleza}!")
        return

    adicionar_log(f"--- Combate contra {nome_fortaleza} ---")

    if personagem_selecionado not in herois_aptos:
        adicionar_log(f"{personagem_selecionado.capitalize()} não está no alcance da fortaleza!")
        return

    taxa_ataque = random.randint(0, 100)

    if taxa_ataque >= 40:
        dano = calcular_dano_fortaleza(personagem_selecionado)
        vida_estruturas[nome_fortaleza] -= dano
        adicionar_log(f"{personagem_selecionado.capitalize()} acerta! -{dano} HP")
    else:
        adicionar_log(f"{personagem_selecionado.capitalize()} erra o ataque!")

    adicionar_log(f"{nome_fortaleza.capitalize()} contra-ataca!")
    aplicar_dano_com_protecao(personagem_selecionado, 8)

    if vida_estruturas[nome_fortaleza] <= 0:
        adicionar_log(f"{nome_fortaleza.capitalize()} conquistada!")
        fortaleza_atual_index += 1
        del mapa_estruturas[pos_fortaleza]

    verificar_estado_jogo()


def realizar_ataque_dragao():
    global estado_jogo
    pos_dragao = next((pos for pos, tipo in mapa_estruturas.items() if tipo == "dragao"), None)
    if not pos_dragao: return

    herois_aptos = obter_herois_aptos_para_atacar(pos_dragao)
    adicionar_log("--- Combate contra o DRAGÃO ---")

    if personagem_selecionado not in herois_aptos:
        adicionar_log(f"{personagem_selecionado.capitalize()} não está no alcance do dragão!")
        return

    taxa_ataque = random.randint(0, 100)

    if taxa_ataque >= 50:
        dano = calcular_dano_dragao(personagem_selecionado)
        vida_estruturas["dragao"] -= dano
        adicionar_log(f"{personagem_selecionado.capitalize()} acerta! -{dano} HP")
    else:
        adicionar_log(f"{personagem_selecionado.capitalize()} erra!")

    for nome_heroi in herois_aptos:
        aplicar_dano_com_protecao(nome_heroi, 15)

    if vida_estruturas["dragao"] <= 0:
        pygame.mixer.music.stop()
        tocar_som(som_vitoria)
        adicionar_log("DRAGÃO DERROTADO! VITÓRIA!")
        estado_jogo = "VITORIA"

    verificar_estado_jogo()


def usar_habilidade_curandeiro(alvo):
    if herois["curandeiro"]["vida"] <= 0:
        adicionar_log("Curandeiro está derrotado!")
        return

    if alvo == "curandeiro":
        adicionar_log("A Curandeira não pode curar a si mesma!")
        return

    if alvo not in herois or herois[alvo]["vida"] <= 0:
        adicionar_log(f"{alvo.capitalize()} não pode ser curado!")
        return

    if herois[alvo]["curas_recebidas"] >= 7:
        adicionar_log(f"A curandeira não pode mais curar {alvo.capitalize()}!")
        return

    cur_c = herois["curandeiro"]["coluna"]
    cur_l = herois["curandeiro"]["linha"]
    alvo_c = herois[alvo]["coluna"]
    alvo_l = herois[alvo]["linha"]

    if abs(cur_c - alvo_c) > 1 or abs(cur_l - alvo_l) > 1:
        adicionar_log(f"{alvo.capitalize()} está fora do alcance da cura!")
        return

    herois[alvo]["vida"] = min(
        herois[alvo]["vida"] + CURA_CURANDEIRO,
        herois[alvo]["vida_max"]
    )
    herois[alvo]["curas_recebidas"] += 1

    adicionar_log(
        f"Curandeiro restaura {CURA_CURANDEIRO} HP de {alvo.capitalize()}! "
        f"({herois[alvo]['curas_recebidas']}/7)"
    )


def activar_protecao_escudeiro(alvo):
    if herois["escudeiro"]["vida"] <= 0:
        adicionar_log("Escudeiro está derrotado!")
        return
    if alvo == "escudeiro":
        adicionar_log("O Escudeiro não pode proteger a si mesmo!")
        return

    if herois["escudeiro"]["protegendo"] == alvo:
        herois["escudeiro"]["protegendo"] = None
        adicionar_log(f"Escudeiro desfez o elo de proteção com {alvo.capitalize()}!")
        return

    if herois["escudeiro"]["protegendo"] is not None:
        adicionar_log(f"Desfaça a proteção atual com {herois['escudeiro']['protegendo'].capitalize()} primeiro!")
        return

    esc_c = herois["escudeiro"]["coluna"]
    esc_l = herois["escudeiro"]["linha"]
    alvo_c = herois[alvo]["coluna"]
    alvo_l = herois[alvo]["linha"]

    if abs(esc_c - alvo_c) > 1 or abs(esc_l - alvo_l) > 1:
        adicionar_log("Alvo muito longe! Fique a 1 bloco do Escudeiro.")
        return

    if herois[alvo]["protecoes_recebidas"] >= 2:
        adicionar_log(f"Escudeiro já protegeu {alvo.capitalize()} 2 vezes!")
        return

    herois["escudeiro"]["protegendo"] = alvo
    herois[alvo]["protecoes_recebidas"] += 1
    adicionar_log(f"Escudeiro agora protege {alvo.capitalize()}! ({herois[alvo]['protecoes_recebidas']}/2)")


# ==========================================
# 7. MOVIMENTO DO DRAGÃO E BATALHA FINAL
# ==========================================
def movimentar_dragao():
    if fortaleza_atual_index < len(ordem_fortalezas) or estado_jogo != "EXPLORACAO":
        return

    pos_dragao = next((pos for pos, t in mapa_estruturas.items() if t == "dragao"), None)
    if not pos_dragao:
        return

    heroi_alvo = None
    menor_dist = 999
    for dados in herois.values():
        if dados["vida"] > 0:
            dist = abs(dados["coluna"] - pos_dragao[0]) + abs(dados["linha"] - pos_dragao[1])
            if dist < menor_dist:
                menor_dist = dist
                heroi_alvo = dados

    if not heroi_alvo:
        return

    destino = (heroi_alvo["coluna"], heroi_alvo["linha"])

    if menor_dist == 1:
        nome_alvo = heroi_alvo["classe"]
        aplicar_dano_com_protecao(nome_alvo, 15)
        verificar_estado_jogo()
        return

    bloqueados = set(mapa_obstaculos.keys())
    for pos, tipo in mapa_estruturas.items():
        if tipo != "dragao":
            bloqueados.add(pos)
    for dados in herois.values():
        pos_h = (dados["coluna"], dados["linha"])
        if dados["vida"] > 0 and pos_h != destino:
            bloqueados.add(pos_h)

    proximo_passo = bfs_proximo_passo(pos_dragao, destino, bloqueados)

    if proximo_passo:
        del mapa_estruturas[pos_dragao]
        mapa_estruturas[proximo_passo] = "dragao"
    else:
        vizinhos_livres = [
            (c, l) for c, l in [(pos_dragao[0] + 1, pos_dragao[1]),
                                (pos_dragao[0] - 1, pos_dragao[1]),
                                (pos_dragao[0], pos_dragao[1] + 1),
                                (pos_dragao[0], pos_dragao[1] - 1)]
            if 0 <= c <= 11 and 0 <= l <= 11 and (c, l) not in bloqueados
        ]
        if vizinhos_livres:
            melhor = min(vizinhos_livres, key=lambda p: abs(p[0] - destino[0]) + abs(p[1] - destino[1]))
            del mapa_estruturas[pos_dragao]
            mapa_estruturas[melhor] = "dragao"


def iniciar_batalha_final():
    global estado_jogo, turnos_jogados
    adicionar_log("--- A BATALHA FINAL COMEÇOU! ---")

    while vida_estruturas["dragao"] > 0 and any(h["vida"] > 0 for h in herois.values()):
        turnos_jogados += 1
        for nome, dados in herois.items():
            if dados["vida"] > 0:
                if random.random() >= 0.50:
                    dano = calcular_dano_dragao(nome)
                    vida_estruturas["dragao"] -= dano
                    adicionar_log(f"{nome.capitalize()} acertou! -{dano} HP")
                else:
                    adicionar_log(f"{nome.capitalize()} errou.")
        if vida_estruturas["dragao"] <= 0:
            break

        vivos = [n for n, d in herois.items() if d["vida"] > 0]
        if vivos:
            alvo = random.choice(vivos)
            adicionar_log(f"Dragão atacou {alvo.capitalize()}!")
            aplicar_dano_com_protecao(alvo, 15)
            vida_estruturas["dragao"] = min(VIDA_DRAGAO, vida_estruturas["dragao"] + 10)
            adicionar_log("Dragão recuperou 10 HP.")

    if vida_estruturas["dragao"] <= 0:
        estado_jogo = "VITORIA"
        pygame.mixer.music.stop()
        tocar_som(som_vitoria)
    else:
        estado_jogo = "DERROTA"
        pygame.mixer.music.stop()
        tocar_som(som_derrota)


def reiniciar_jogo():
    global herois, personagem_selecionado, estado_jogo
    global fortaleza_atual_index, vida_estruturas, turnos_jogados
    global mapa_estruturas, mapa_obstaculos, mapa_itens, lista_inimigos

    herois = criar_herois()
    mapa_estruturas = {
        (6, 6): "dragao",
        (2, 5): "fortaleza1",
        (5, 10): "fortaleza2",
        (8, 3): "fortaleza3",
        (11, 11): "santuario"
    }
    vida_estruturas = {
        "fortaleza1": VIDA_FORTALEZA,
        "fortaleza2": VIDA_FORTALEZA,
        "fortaleza3": VIDA_FORTALEZA,
        "dragao": VIDA_DRAGAO
    }
    fortaleza_atual_index = 0
    turnos_jogados = 0
    personagem_selecionado = "guerreiro"
    estado_jogo = "EXPLORACAO"
    mensagem_log.clear()

    mapa_obstaculos = copy.deepcopy(mapa_obstaculos_inicial)
    mapa_itens = copy.deepcopy(mapa_itens_inicial)
    lista_inimigos = copy.deepcopy(lista_inimigos_inicial)

    try:
        pygame.mixer.music.play(-1)
    except:
        pass
    adicionar_log("Jogo reiniciado!")


# ==========================================
# 8. LOOP PRINCIPAL DO JOGO
# ==========================================
loop = True
clock = pygame.time.Clock()

while loop:
    passou_turno = False

    # --- A. EVENTOS E MOVIMENTAÇÃO ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            loop = False

        # Lida com o redimensionamento da janela
        elif event.type == pygame.VIDEORESIZE:
            janela = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                reiniciar_jogo()
                continue

            if estado_jogo in ["VITORIA", "DERROTA"]:
                continue

            teclas_personagens = {pygame.K_1: "guerreiro", pygame.K_2: "arqueiro", pygame.K_3: "curandeiro",
                                  pygame.K_4: "mago", pygame.K_5: "escudeiro"}
            if event.key in teclas_personagens:
                personagem_selecionado = teclas_personagens[event.key]

            elif event.key == pygame.K_SPACE:
                if fortaleza_atual_index < len(ordem_fortalezas):
                    realizar_ataque_fortaleza()
                else:
                    realizar_ataque_dragao()
                passou_turno = True
            elif event.key == pygame.K_c:
                usar_habilidade_curandeiro(personagem_selecionado)
                passou_turno = True
            elif event.key == pygame.K_p:
                activar_protecao_escudeiro(personagem_selecionado)
                passou_turno = True

            elif event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]:
                if herois[personagem_selecionado]["vida"] <= 0:
                    adicionar_log(f"{personagem_selecionado.capitalize()} está derrotado!")
                    continue

                col_futura, lin_futura = herois[personagem_selecionado]["coluna"], herois[personagem_selecionado][
                    "linha"]

                if event.key == pygame.K_UP and lin_futura > 0:
                    lin_futura -= 1
                elif event.key == pygame.K_DOWN and lin_futura < 11:
                    lin_futura += 1
                elif event.key == pygame.K_LEFT and col_futura > 0:
                    col_futura -= 1
                elif event.key == pygame.K_RIGHT and col_futura < 11:
                    col_futura += 1

                if mapa_estruturas.get((col_futura, lin_futura)) == "santuario":
                    if fortaleza_atual_index >= len(ordem_fortalezas):
                        iniciar_batalha_final()
                    else:
                        adicionar_log("Destrua as fortalezas antes!")
                    continue

                bateu = (col_futura, lin_futura) in mapa_obstaculos or (col_futura, lin_futura) in mapa_estruturas

                if not bateu:
                    for nome_heroi, dados_heroi in herois.items():
                        if nome_heroi != personagem_selecionado and dados_heroi["coluna"] == col_futura and dados_heroi[
                            "linha"] == lin_futura:
                            if not (col_futura == 0 and lin_futura == 0):
                                bateu = True
                                break

                inimigo_encontrado = next(
                    (i for i in lista_inimigos if i["coluna"] == col_futura and i["linha"] == lin_futura), None)

                if inimigo_encontrado:
                    realizar_encontro_inimigo(personagem_selecionado, inimigo_encontrado)
                    herois[personagem_selecionado]["coluna"] = col_futura
                    herois[personagem_selecionado]["linha"] = lin_futura
                    verificar_estado_jogo()
                    passou_turno = True

                elif not bateu:
                    herois[personagem_selecionado]["coluna"], herois[personagem_selecionado][
                        "linha"] = col_futura, lin_futura
                    pos_atual = (col_futura, lin_futura)

                    if pos_atual in mapa_itens:
                        item = mapa_itens[pos_atual]
                        if item == "pocao":
                            tocar_som(som_encontro_pocao)
                            herois[personagem_selecionado]["vida"] = min(
                                herois[personagem_selecionado]["vida"] + CURA_POCAO,
                                herois[personagem_selecionado]["vida_max"])
                            adicionar_log(f"{personagem_selecionado.capitalize()} usou poção! +{CURA_POCAO} HP")
                        elif item == "pergaminho":
                            tocar_som(som_encontro_pergaminho)
                            herois[personagem_selecionado]["pergaminhos"] += 1
                            adicionar_log(
                                f"{personagem_selecionado.capitalize()} pegou pergaminho! +{int(BONUS_PERGAMINHO * 100)}% atk")
                        del mapa_itens[pos_atual]
                    passou_turno = True

    if passou_turno:
        turnos_jogados += 1
        movimentar_dragao()

    # --- B. DESENHO NA TELA VIRTUAL ---
    tela_virtual.fill(C_BG)

    for lin in range(12):
        for col in range(12):
            x, y = col * LARGURA_CELULA, lin * ALTURA_CELULA
            pos = (col, lin)
            tipo = mapa_estruturas.get(pos)
            cor = (150, 150, 150) if tipo == "dragao" else C_CELL_BASE
            pygame.draw.rect(tela_virtual, cor, (x, y, LARGURA_CELULA, ALTURA_CELULA))
            pygame.draw.rect(tela_virtual, C_GRID, (x, y, LARGURA_CELULA, ALTURA_CELULA), 1)

    # Desenha a base na coordenada (0, 0)
    img_base = visuais_objetos["base"]
    w_b, h_b = img_base.get_size()
    tela_virtual.blit(img_base, ((LARGURA_CELULA - w_b) // 2, (ALTURA_CELULA - h_b) // 2))

    dados_sel = herois[personagem_selecionado]
    if dados_sel["vida"] > 0:
        c_h, l_h = dados_sel["coluna"], dados_sel["linha"]
        for dc, dl in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            c_adj, l_adj = c_h + dc, l_h + dl
            if 0 <= c_adj <= 11 and 0 <= l_adj <= 11:
                desenhar_destaque_transparente(tela_virtual, c_adj * LARGURA_CELULA, l_adj * ALTURA_CELULA,
                                               LARGURA_CELULA,
                                               ALTURA_CELULA, C_HIGHLIGHT)

    for (col, lin), tipo in mapa_estruturas.items():
        if tipo == "dragao" and fortaleza_atual_index >= len(ordem_fortalezas):
            img = visuais_objetos["dragao_acordado"]
        else:
            img = visuais_objetos[tipo]
        w, h = img.get_size()
        x, y = col * LARGURA_CELULA + (LARGURA_CELULA - w) // 2, lin * ALTURA_CELULA + (ALTURA_CELULA - h) // 2
        tela_virtual.blit(img, (x, y))

    for (col, lin), tipo in mapa_obstaculos.items():
        img = visuais_objetos[tipo]
        w, h = img.get_size()
        tela_virtual.blit(img,
                          (col * LARGURA_CELULA + (LARGURA_CELULA - w) // 2,
                           lin * ALTURA_CELULA + (ALTURA_CELULA - h) // 2))

    for (col, lin), tipo in mapa_itens.items():
        img = visuais_objetos[tipo]
        w, h = img.get_size()
        tela_virtual.blit(img,
                          (col * LARGURA_CELULA + (LARGURA_CELULA - w) // 2,
                           lin * ALTURA_CELULA + (ALTURA_CELULA - h) // 2))

    for inimigo in lista_inimigos:
        w, h = imagem_inimigo.get_size()
        tela_virtual.blit(imagem_inimigo, (inimigo["coluna"] * LARGURA_CELULA + (LARGURA_CELULA - w) // 2,
                                           inimigo["linha"] * ALTURA_CELULA + (ALTURA_CELULA - h) // 2))

    for nome_heroi, dados in herois.items():
        if dados["vida"] > 0:

            # Esconde o herói e sua barra de vida se estiver na base (0, 0)
            if dados["coluna"] == 0 and dados["linha"] == 0:
                continue

            img = imagens[nome_heroi]
            w, h = img.get_size()
            x, y = dados["coluna"] * LARGURA_CELULA + (LARGURA_CELULA - w) // 2, dados["linha"] * ALTURA_CELULA + (
                    ALTURA_CELULA - h) // 2
            tela_virtual.blit(img, (x, y))

            hp_percent = dados["vida"] / dados["vida_max"]
            cor_hp = (0, 255, 0) if hp_percent > 0.5 else (255, 255, 0) if hp_percent > 0.25 else (255, 0, 0)
            pygame.draw.rect(tela_virtual, (50, 50, 50), (x + 5, y - 8, 40, 4))
            pygame.draw.rect(tela_virtual, cor_hp, (x + 5, y - 8, int(40 * hp_percent), 4))


    # ==========================================
    # C. LÓGICA DA BARRA LATERAL (NOVO)
    # ==========================================
    # Fundo e Borda da barra lateral (Inicia onde o mapa acaba em x=792)
    largura_sidebar = LARGURA_ORIGINAL - (12 * LARGURA_CELULA) # 991 - 792 = 199
    pygame.draw.rect(tela_virtual, C_SIDEBAR_BG, (12 * LARGURA_CELULA, 0, largura_sidebar, ALTURA_ORIGINAL))
    pygame.draw.rect(tela_virtual, C_BORDA_TEXTO, (12 * LARGURA_CELULA, 0, largura_sidebar, ALTURA_ORIGINAL), 3)

    centro_x_sidebar = (12 * LARGURA_CELULA) + (largura_sidebar // 2)

    # 1. Título do Jogo
    texto_titulo = "Eldoria"
    w_titulo = fonte_titulo.render(texto_titulo, True, C_TEXTO).get_width()
    desenhar_texto_com_contorno(tela_virtual, texto_titulo, fonte_titulo, C_TEXTO, C_BORDA_TEXTO, centro_x_sidebar - (w_titulo // 2), 15)

    # 2. Estruturas (Fortalezas e Dragão)
    elementos_sidebar = [
        ("fortaleza1", "Fortaleza 1"),
        ("fortaleza2", "Fortaleza 2"),
        ("fortaleza3", "Fortaleza 3"),
        ("dragao", "Dragão")
    ]

    y_offset = 65
    for chave, nome_display in elementos_sidebar:
        img_str = visuais_objetos[chave]
        w_img, h_img = img_str.get_size()

        # Desenha a imagem
        tela_virtual.blit(img_str, (centro_x_sidebar - (w_img // 2), y_offset))

        # Status (HP / Destruída)
        hp = vida_estruturas.get(chave, 0)
        status_texto = f"HP: {hp}" if hp > 0 else "Destruída"
        if hp <= 0 and chave == "dragao":
            status_texto = "Derrotado"

        # Desenha Nome
        w_nome = fonte_pequena.render(nome_display, True, C_TEXTO).get_width()
        desenhar_texto_com_contorno(tela_virtual, nome_display, fonte_pequena, C_TEXTO, C_BORDA_TEXTO, centro_x_sidebar - (w_nome // 2), y_offset + h_img + 2)

        # Desenha HP
        w_hp = fonte_pequena.render(status_texto, True, C_TEXTO).get_width()
        desenhar_texto_com_contorno(tela_virtual, status_texto, fonte_pequena, C_TEXTO, C_BORDA_TEXTO, centro_x_sidebar - (w_hp // 2), y_offset + h_img + 20)

        y_offset += h_img + 45 # Espaçamento para o próximo elemento

    # --- FIM DA LÓGICA DA BARRA LATERAL ---


    # --- LÓGICA RETRATOS E UI INFERIOR ---
    if retratos:
        padrao = {"retrato": (-8, 510), "texto": (70, 695)}
        posicao = posicoes_customizadas.get(personagem_selecionado, padrao)

        tela_virtual.blit(retratos[personagem_selecionado], posicao["retrato"])

        pos_x_texto = posicao["texto"][0]
        pos_y_texto = posicao["texto"][1]

        desenhar_texto_com_contorno(
            tela_virtual,
            personagem_selecionado.capitalize(),
            fonte,
            C_TEXTO,
            C_BORDA_TEXTO,
            pos_x_texto,
            pos_y_texto
        )

    info_texto = f"HP: {dados_sel['vida']}/{dados_sel['vida_max']} | Pergaminhos: {dados_sel['pergaminhos']} | Bônus: {int((dados_sel['bonus_ataque'] + dados_sel['pergaminhos'] * BONUS_PERGAMINHO - 1) * 100)}%"
    desenhar_texto_com_contorno(tela_virtual, info_texto, fonte, C_TEXTO, C_BORDA_TEXTO, 340, 530)

    tempo_atual = pygame.time.get_ticks()
    mensagem_log = [m for m in mensagem_log if tempo_atual - m["tempo"] < 4000]

    for i, m in enumerate(mensagem_log):
        desenhar_texto_com_contorno(tela_virtual, m["texto"], fonte_pequena, C_TEXTO, C_BORDA_TEXTO, 490, 580 + i * 20)

    instrucoes1 = "1-5: Selecionar Personagem | Setas: Mover "
    desenhar_texto_com_contorno(tela_virtual, instrucoes1, fonte_pequena, C_TEXTO, C_BORDA_TEXTO, 420, 680)
    instrucoes2 = "Espaço: Atacar | C: Curar | P: Proteger | R: Reiniciar"
    desenhar_texto_com_contorno(tela_virtual, instrucoes2, fonte_pequena, C_TEXTO, C_BORDA_TEXTO, 390, 700)

    if estado_jogo == "VITORIA":
        desenhar_texto_com_contorno(tela_virtual, "VITÓRIA! O Dragão foi derrotado!", fonte, C_TEXTO, C_BORDA_TEXTO,
                                    250, 250)
    elif estado_jogo == "DERROTA":
        desenhar_texto_com_contorno(tela_virtual, "DERROTA! Todos os heróis caíram...", fonte, C_TEXTO, C_BORDA_TEXTO,
                                    250,
                                    250)

    # -------------------------------------------------------------
    # ESCALA FINAL PARA A JANELA
    tamanho_atual_janela = janela.get_size()
    tela_final = pygame.transform.smoothscale(tela_virtual, tamanho_atual_janela)
    janela.blit(tela_final, (0, 0))
    # -------------------------------------------------------------

    pygame.display.update()
    clock.tick(60)

pygame.quit()