import random
import pygame


pygame.init()

# 1. CONFIGURAÇÕES DA JANELA
    #tamanho da tela
janela = pygame.display.set_mode((800, 600))
    #título do jogo
pygame.display.set_caption("Eldoria")

    #imagem de fundo
imagem_fundo = pygame.image.load('MapaEldoriaComEstruturasV1.png')


# 2. CONFIGURAÇÕES DOS PERSONAGENS
    #imagens/tamanho
imagens = {
    "guerreiro": pygame.transform.scale(
        pygame.image.load('guerreiro.png'), (55, 70)),
    "arqueiro": pygame.transform.scale(
        pygame.image.load('arqueiro.png'), (55, 70)),
    "curandeiro": pygame.transform.scale(
        pygame.image.load('curandeiro.png'), (55, 70)),
    "mago": pygame.transform.scale(pygame.image.load('mago.png'),
                                   (55, 70)),
    "escudeiro": pygame.transform.scale(
        pygame.image.load('escudeiro.png'), (55, 70))
}

    #posição inicial de cada um na tela
posicoes = {
    "guerreiro": {"x": 10, "y": 30},
    "arqueiro": {"x": 1, "y": 20},
    "curandeiro": {"x": 20, "y": 1},
    "mago": {"x": 10, "y": 1},
    "escudeiro": {"x": 1, "y": 1}
}

# --- CONFIGURAÇÃO DOS INIMIGOS  ---
# Carrega e ajusta o tamanho da imagem dos inimigos
imagem_inimigo = pygame.transform.scale(pygame.image.load('inimigosv2.png'), (55, 75))

lista_inimigos = []
# Cria 30 inimigos em posições aleatórias sem colisão
# Rect para não nascerem na base
base_rect = pygame.Rect(0, 0, 150, 150)

# Usamos um 'while' para rodar até que a lista tenha 30 inimigos válidos
while len(lista_inimigos) < 30:
    # Sorteia X e Y
    x_aleatorio = random.randint(0, 800 - 55)
    y_aleatorio = random.randint(0, 600 - 70)

    # Cria o retângulo do inimigo que acabou de ser sorteado
    rect_novo = pygame.Rect(x_aleatorio, y_aleatorio, 55, 70)

    sobreposto = False  # Começamos assumindo que o espaço está livre

    # 1. Verifica se nasceu em cima da base
    if rect_novo.colliderect(base_rect):
        sobreposto = True

    # 2. Verifica se nasceu em cima de um inimigo que já está na lista
    for inimigo in lista_inimigos:
        rect_existente = pygame.Rect(inimigo["x"], inimigo["y"], 55, 70)

        if rect_novo.colliderect(rect_existente):
            sobreposto = True
            break

    if not sobreposto:
        # inimigo adicionado
        lista_inimigos.append({"x": x_aleatorio, "y": y_aleatorio})


    #velocidade
vel_player = 0.3

    #define quem começa sendo controlado quando o jogo abre
personagem_selecionado = "guerreiro"



# 3. LOOP PRINCIPAL DO JOGO
loop = True

while loop:
    # --- A. EVENTOS E SELEÇÃO DE PERSONAGEM ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            loop = False

        # Troca o personagem ao apertar os números de 1 a 5
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                personagem_selecionado = "guerreiro"
                print("Guerreiro selecionado!")
            elif event.key == pygame.K_2:
                personagem_selecionado = "arqueiro"
                print("Arqueiro selecionado!")
            elif event.key == pygame.K_3:
                personagem_selecionado = "curandeiro"
                print("Curandeiro selecionado!")
            elif event.key == pygame.K_4:
                personagem_selecionado = "mago"
                print("Mago selecionado!")
            elif event.key == pygame.K_5:
                personagem_selecionado = "escudeiro"
                print("Escudeiro selecionado!")

    # --- B. MOVIMENTAÇÃO DO PERSONAGEM ATIVO ---
    teclas = pygame.key.get_pressed()

    # Atualiza apenas as coordenadas do personagem que está selecionado
    if teclas[pygame.K_UP]:
        posicoes[personagem_selecionado]["y"] -= vel_player
    if teclas[pygame.K_DOWN]:
        posicoes[personagem_selecionado]["y"] += vel_player
    if teclas[pygame.K_LEFT]:
        posicoes[personagem_selecionado]["x"] -= vel_player
    if teclas[pygame.K_RIGHT]:
        posicoes[personagem_selecionado]["x"] += vel_player

# --- COLISÕES COM AS BORDAS DA TELA (800x600) ---
# Limita o eixo X (Esquerda e Direita)
    if posicoes[personagem_selecionado]["x"] < 0:
            posicoes[personagem_selecionado]["x"] = 0
    elif posicoes[personagem_selecionado]["x"] > 800 - 55:  # 800 (tela) - 55 (largura do sprite)
            posicoes[personagem_selecionado]["x"] = 800 - 55

# Limita o eixo Y (Cima e Baixo)
    if posicoes[personagem_selecionado]["y"] < 0:
            posicoes[personagem_selecionado]["y"] = 0
    elif posicoes[personagem_selecionado]["y"] > 600 - 70:  # 600 (tela) - 70 (altura do sprite)
            posicoes[personagem_selecionado]["y"] = 600 - 70

    # --- C. DESENHO NA TELA ---
    janela.blit(imagem_fundo, (0, 0))

    # --- DESENHA OS INIMIGOS ---
    for inimigo in lista_inimigos:
        janela.blit(imagem_inimigo, (inimigo["x"], inimigo["y"]))

    # --- DESENHA PLAYERS ---
    for nome_do_heroi in imagens:
        img = imagens[nome_do_heroi]
        x = posicoes[nome_do_heroi]["x"]
        y = posicoes[nome_do_heroi]["y"]
        janela.blit(img, (x, y))

    # Atualiza a tela
    pygame.display.update()

# Encerra o Pygame corretamente ao sair do loop
pygame.quit()